/* Name : sanjana B
 * date : 30/09/2024
 * description : addressBook 
 * sample execution : createcontact -> name : sanjana  contact : 1234567890  email : sanju@gmail.com
 * searchcontact -> searchby 1.name 2. number 3 . email enter option 1 : 
 * sanjana   1234567890     sanju@gmail.com 
 * editcontact -> searchby 1.name 2.number 3.email enter option 1 sanjana 1234567890 sanju@gmail.com. which do you want to edit 1.name2.number3.email enter the option 1.name sanju 
 * deletecontact -> searchby 1.name2.number3.email enter option display the contact then it delete 
 * listcontact -> contacts list
 * sl.no       name        number        email
 * 1           sanju       1234567890    sanju@gmail.com
 * */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
void listContacts(AddressBook *addressBook){
		if(addressBook->contactCount == 0) {
	   		   printf("No contacts is present\n");
	   		   return;
	   }
	   	printf("\nList of Contact:\n");
	   	int i;
	   	printf("----------------------------------------------------------------------------\n");
	   	printf("%s\t%s\t%s\t%s\n", "sl.no", "Name", "Ph.No", "Email.id");
	   	printf("----------------------------------------------------------------------------\n");
	   	for (i = 0; i < addressBook->contactCount; i++)	   	{
	   			printf ("%d\t%s\t%s\t%s\n", i + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    }
    	printf("----------------------------------------------------------------------------\n");
}
void saveAndExit(AddressBook *addressBook){
  saveContactsToFile (addressBook);	// Save contacts to file
  exit (EXIT_SUCCESS);		// Exit the program
}
int valid_name(char *name){
		int j;
		for(j = 0; name[j] != '\0'; j++)	{
				if((name[j] > 0 && name[j] < 65) || (90 > name[j] && 97 < name[j])&& name[j] > 122){
						if(name[j] != ' ' && name[j] != '\t')						{			// to check the char only should be this
							printf("Error: Please enter only characters!!\n");
							return 0;
						}
				}
		}
		return 1;
}
int valid_number(AddressBook *addressBook, char *ph_no){
		int i;
		for(i = 0; ph_no[i] != '\0'; i++){
				if(ph_no[i] < '0' || ph_no[i] > '9')	{			// num should only 0 to 9 
	              printf("Error: Phone number must contain digits only!\n");
	              return 0;
	            }
	    }
	    if(strlen (ph_no) != 10) {
                                   printf("Error: Please enter only 10 digits!!\n");
                                   return 0;
        }
        for(i = 0; i < addressBook->contactCount; i++){
        		if(strcmp (ph_no, addressBook->contacts[i].phone) == 0){			// to check already number is present or not
	                                  printf("Error: Number already in use\n");
	                                  return 0;
	            }
	    }
	    return 1;
}
int valid_email(AddressBook *addressBook, char *email){
		int i;
		char *at_symbol = strstr (email, "@");	// giving the @ and .com present in main string or not
	    char *dot_symbol = strstr (email, ".com");
	    if(at_symbol == NULL || dot_symbol == NULL) {
	    		printf("Error: Invalid email. Must have @ and .com\n");
	    		return 0;
    }
    	if(dot_symbol <= at_symbol + 1){				// between that char should be present
           printf("Error: Invalid email. Must have valid characters between @ and .com\n");
           return 0;
    }
    	for(i = 0; i < addressBook->contactCount; i++){				// checking for already email is in use or not
      if(strcmp (email, addressBook->contacts[i].email) == 0){
	  printf("Error: Email already in use\n");
	  return 0;
	}
    }
  return 1;
}
void createContact(AddressBook *addressBook){
labeln1:printf("enter Name : ");
		scanf(" %[^\n]", addressBook->contacts[addressBook->contactCount].name);
		if(!(valid_name (addressBook->contacts[addressBook->contactCount].name))) {
                           goto labeln1;		// bcz it need to go again asking for name
    }
labeln2: printf("enter Phone number : ");
		 scanf("%s", addressBook->contacts[addressBook->contactCount].phone);
		 if(! (valid_number (addressBook, addressBook->contacts[addressBook->contactCount].phone))) {
                              goto labeln2;		// bcz it need to go again asking for number
    }
labeln3: printf ("enter email : ");
		 scanf("%s", addressBook->contacts[addressBook->contactCount].email);
		 if(!   (valid_email (addressBook, addressBook->contacts[addressBook->contactCount].email))){
                               goto labeln3;		// bcz it need to go again asking for email
    }
    	 addressBook->contactCount++;
    	 printf("contact created successfully");
}
void searchContact(AddressBook *addressBook, int *flag_found){
		char res[50];			// taking string to store
		int i, op,p;
		printf("Enter the option you know:\n");
		printf("1. Name\n2. Phone Number\n3. Email ID\nEnter the option: ");
		scanf("%d", &op);
		switch(op) {
				case 1:
						printf("Enter the Name: ");
						scanf(" %[^\n]", res);
						printf("Searching for: %s\n", res);
						for(i = 0; i < addressBook->contactCount; i++)	{
								if(strcmp (addressBook->contacts[i].name, res) == 0)	    {			// checking already exiting name and new name is same or not
	                              if(!(*flag_found)){
	                              		  printf("Name(s) found:\n");
	                              		  printf("Sl.No\tName\tPhone Number\tEmail\n");
	                              }
	                              printf("%d\t%s\t%s\t%s\t\n", i + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone,
		      addressBook->contacts[i].email);
		      					 p++;
		      					  // *flag_found = 1;	// if the similar name found 
	    }*flag_found = p;
	}
						if(!(*flag_found))
								printf ("No contact found with the given name.\n");
						break;
				case 2:
						printf("Enter the Phone Number: ");
						scanf("%s", res);
						for(i = 0; i < addressBook->contactCount; i++){
								if(strcmp (addressBook->contacts[i].phone, res) == 0)	    {			// comparing old num with new num
	                                    if(!(*flag_found))	{
	                                    		printf("Phone number found:\n");
	                                    		printf("Sl.No\tName\tPhone Number\tEmail\n");
	                                    }
	                                    printf("%d\t%s\t%s\t%s\t\n", i + 1,addressBook->contacts[i].name, addressBook->contacts[i].phone,addressBook->contacts[i].email);
	                                    *flag_found = 1;	// if the cont is present it will be 1
	                                    						}
						}
						if(!(*flag_found)){
								printf("No contact found with the given phone number.\n");
						}
						break;
				case 3:
						printf("Enter the Email: ");
						scanf("%s", res);
						for(i = 0; i < addressBook->contactCount; i++){
								if(strcmp (addressBook->contacts[i].email, res) == 0) {
										if(!(*flag_found)){
												printf("Email found:\n");
												printf("Sl.No\tName\tPhone Number\tEmail\n");
										}
										printf("%d\t%s\t%s\t%s\t\n", i + 1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
	                                       *flag_found = 1;	// if the email is present it will be 1
	    }
	}
						if (!(*flag_found))
								printf("No contact found with the given email.\n");
						break;
				default:
						printf("Invalid option. Please try again.\n");
						break;
		}
}
void editContact(AddressBook * addressBook){
		int flag_found = 0,index = -1,op,i;
		char res[50];
		searchContact(addressBook,&flag_found);
		if(flag_found == 0){
				printf("no contact\n");
				return ;
		}
		if(flag_found > 1)   // if any similar same are present
		{
				printf("similar  name found go for phone or email\n");
				printf("1.number\n2.emailid\nenter ur option : ");
				scanf("%d",&op);
				if(op == 1){
						printf("enter number : ");
						scanf("%s",res);
				}
				else if(op == 2){
						printf("enter email : ");
						scanf("%s",res);
				}
				else{
						printf("invalid input\n");
						return;
				}
				//index = -1; // checking that is present in the database or not
				for(i = 0 ; i< addressBook->contactCount;i++)	{
						if((op == 1 && strcmp(addressBook->contacts[i].phone,res) == 0) || (op == 2 && strcmp(addressBook->contacts[i].email,res) == 0))	{
								index = i;  // storing that to index
								break;
						}
				}
				if(index == -1) 	{ // if no contact present after searching
						printf("contact not found\n");
						return;
				}
		}
		else	{
				for(i = 0 ; i < addressBook->contactCount;i++)	{
						if(strcmp(addressBook->contacts[i].name," ")!='\0'){ // if any unique contact is present
								index = i;
								break;
						}}
		}
		int choice;
		printf("Which one do you want to edit?\n");
		printf("1. Name\n2. Number\n3. Email\nEnter your option: ");
		scanf("%d", &choice);
		switch(choice){
				case 1:
labelname : printf("Enter new name: ");
			scanf(" %[^\n]", res);
			if(!valid_name (res)){
	        goto labelname;	// same validation for new name edition 
	  }
	  		strcpy(addressBook->contacts[index].name, res);	// copying the new name to old name index 
	        printf("Name updated\n");
	        break;
	        	case 2:
labelnumber: printf("Enter new number: ");
			 scanf("%s", res);
			 if(!(valid_number (addressBook, res))){
	           goto labelnumber;
	  }
	  		strcpy(addressBook->contacts[index].phone, res);	// validation for the new number and storing
	        printf("Number updated\n");
	        break;
	        	case 3:
labelemail: printf("Enter new email: ");
		    scanf("%s", res);
		    if(!valid_email (addressBook, res)) {
		   		   goto labelemail;	// validation for the new email 
	 }
	 	   strcpy(addressBook->contacts[index+1].email, res);	// storing that new email into the old email index
	 	   printf("Email updated\n");
	 	   break;
	 	   		default : printf("Invalid option\n");
	 	   				  break;
	 	}
}
void deleteContact(AddressBook * addressBook){
		
		int op, i,j,index = 0;
		char res[100];
		printf("Delete Contact by:\n1. Name\n2. Mobile Number\n3. Email\n");
		scanf("%d", &op);
		switch (op) {
				case 1:
						printf("Enter Name: ");
						scanf(" %[^\n]", res);  
				        for (i = 0; i < addressBook->contactCount; i++) {
				        if (strcmp(res, addressBook->contacts[i].name) == 0) {   
				        		j = i;
				        		index++;
				        
						}
						}
				        if (index == 0) {  // No contact found
				        printf("Contact not found.\n");
				        return;                                          
				        }
				        if (index == 1) {
				        		for (i = j; i < addressBook->contactCount - 1; i++) {
				        				                    addressBook->contacts[i] = addressBook->contacts[i + 1];  
				        		}
				        }
						else {
								printf("Two names are found\n Enter 1.phone number or \n 2. Mail Id\n");
								int num;	                       		                                                                                                scanf("%d",&num);
								char res1[30];
								switch(num)
								{
										 case 1:index = 0;
									 		for(i=0;i<addressBook->contactCount;i++){
									 				if(strcmp(res1,addressBook->contacts[i].phone)==0)
													{
															index++;
												    }
													if(index != 0)   //Checking count equal to zero or n
													{
															addressBook->contacts[i]=addressBook->contacts[i+1];  //shifting the index from i+1             
												    }
											}                                                                                                                                                   break;
										 case 2:printf("Enter email:");
									 		for(i=0;i<addressBook->contactCount;i++){
									 				if(strcmp(res1,addressBook->contacts[i].email)==0)
													{
															index++;
												    }
													if(index != 0)   //Checking count equal to zero or n
													{
															addressBook->contacts[i]=addressBook->contacts[i+1];  //shifting the index from i+1             
												    }                                                                                                                            }                                                                                                                                                   break;
								}
						}
				case 2:printf("Enter Mobile:");
			 		scanf(" %[^\n]",res);
			 		for(i = 0;i<addressBook->contactCount;i++)
					{
			 				if(strcmp(res,addressBook->contacts[i].phone)==0) 
							{
									index++;
							}
							if(index != 0)
							{
									addressBook->contacts[i]=addressBook->contacts[i+1];  //shifting the index from i+1             
						    }
					}
					break;
			 case 3:printf("Enter Mail:");
			 		scanf(" %[^\n]",res);
			 		for(i=0;i<addressBook->contactCount;i++)
					{
			 				if(strcmp(res,addressBook->contacts[i].email)==0) 
							{
									index++;
							}
							if(index != 0)
							{
									addressBook->contacts[i]=addressBook->contacts[i+1];  //shifting the index from i+1             
						    }
					}
					break;
		}
         if(index !=0)
		 {
		 		 addressBook->contactCount--;
        	printf ("contact deleted successfully\n");
		 }
		 else
		 {
		 		 printf("contact not deleted");
		 		// addressBook->contactCount++;
		 }
} 
