/* Name : sanjana B
 * date : 30/09/2024
 * description : addressBook */

#ifndef FILE_H
#define FILE_H

#include "contact.h"

void saveContactsToFile(AddressBook *addressBook); // calling the both save and load function
void loadContactsFromFile(AddressBook *addressBook);

#endif
