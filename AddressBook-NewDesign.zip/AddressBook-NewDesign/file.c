/* Name : sanjana B
 * date : 30/09/2024
 * description : addressBook 
 * sample database saving in the file : 3
deepa,1029837465,deepa@gmail.com
san,0987654321,san@12.com */

#include <stdio.h>
#include "file.h"
#include "contact.h"

int openfile(AddressBook *addressBook)
{
		addressBook->fptr_file = fopen("addressBook.csv", "r"); // creating the file and opening

		if(addressBook->fptr_file == NULL) // validating is peresent or not
		{
				perror("fopen");
				printf("file not opened\n");			
				return -1;
		}
		return 0;
} 
void saveContactsToFile(AddressBook *addressBook) {
	
		FILE *fptr_temp = fopen("temp.csv", "w"); // creating the temporary file and writing the contacts
		if(fptr_temp == NULL) // validating the file is persent or not
		{
				perror("fopen");
				printf("file not opened\n");
				return;
		}
		int i ;
		fprintf(fptr_temp , "%d\n",addressBook->contactCount); // that should count how much contact is present inthe file
		for(i = 0 ; i < addressBook->contactCount ;i++)
		{
				fprintf(fptr_temp , "%s",addressBook->contacts[i].name);
				fprintf(fptr_temp , "%c" , ','); // in the file it should store like this
				fprintf(fptr_temp,"%s",addressBook->contacts[i].phone);
				fprintf(fptr_temp,"%c",',');
				fprintf(fptr_temp,"%s",addressBook->contacts[i].email);
				fprintf(fptr_temp,"\n");
		}
		remove("addressBook.csv"); 
		rename("temp.csv" , "addressBook.csv");// renaming the temp file to our org file 
		printf("saved file!!\n");
  
}

void loadContactsFromFile(AddressBook *addressBook) {
		int i;
		addressBook->contactCount = 0; // it should be 0 otherwise it will be fill with gv
		fscanf(addressBook->fptr_file , "%d\n" ,&addressBook->contactCount);
		for(i = 0 ;i < addressBook->contactCount ;i++)
		{
				fscanf(addressBook->fptr_file, "%[^,]" ,addressBook->contacts[i].name ); // read upto ,
				fseek(addressBook->fptr_file,1,SEEK_CUR);   

				fscanf(addressBook->fptr_file,"%[^,]",addressBook->contacts[i].phone);
				fseek(addressBook->fptr_file,1,SEEK_CUR);
				fscanf(addressBook->fptr_file,"%[^\n]",addressBook->contacts[i].email);
				fseek(addressBook->fptr_file,1,SEEK_CUR);
				
		}
		//fclose(addressBook->fptr_file);
		printf("loaded file!!\n");
    
}
