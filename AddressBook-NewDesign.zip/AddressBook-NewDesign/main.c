/* Name : sanjana B
 * date : 30/09/2024
 * description : addressBook 
 *sample execution : Address Book Menu:
 1. Create contact
 2. Search contact
 3. Edit contact
 4. Delete contact
 5. List all contacts
 6. Exit
 Enter your choice: 7
 invalid choice*/

#include <stdio.h>
#include "contact.h"
#include "file.h"

int main() {
    int choice;
    AddressBook addressBook;
    int flag_found = 0;
    openfile(&addressBook);
  //  initialize(&addressBook); // Initialize the address book


     loadContactsFromFile(&addressBook);
    do {
        printf("\nAddress Book Menu:\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        if(scanf("%d", &choice) == 1)	{
				if(choice >= 1 && choice <= 6){ // to check that with in the range
						switch (choice) {
								case 1:createContact(&addressBook);
                                       break;
                                case 2:searchContact(&addressBook,&flag_found);
                                       break;
                                case 3:editContact(&addressBook);
                                       break;
                               case 4:deleteContact(&addressBook);
                               		  //addressBook.contactCount--;
                                       break;
                               case 5: listContacts(&addressBook);
                                        break;
                               case 6 :printf("Saving and Exiting...\n");
                               		   saveContactsToFile(&addressBook);
                                        break; 
                        }
				}
				else{
						printf("invalid choice\n");
				}
		}
		else{
				printf("pls enter digit only!!\n"); // if any kind of character or special char 
				while(getchar() != '\n'); // to avoid the buffer in input buffer
				} 
    } while (choice != 6);   
    return 0;
}
