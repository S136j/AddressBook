
/* Name : sanjana B
 * date : 30/09/2024
 * description : addressBook */

#include <stdio.h>
#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100 // defining macro of fixed array size

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
    
} Contact; // which will act like dt

typedef struct {
    Contact contacts[MAX_CONTACTS]; // dec the array of structure
    FILE *fptr_file; // dec the file *
    int contactCount;  // to get the contact count
} AddressBook;
void createContact(AddressBook *addressBook);
int valid_name(char *name);
int valid_number(AddressBook *addressBook ,char *ph_no);
int valid_email(AddressBook *addressBook,char *email);
void searchContact(AddressBook *addressBook,int *flag_found);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
//void initialize(AddressBook *addressBook);
int openfile(AddressBook *addressBook);
void saveContactsToFile(AddressBook *AddressBook);

#endif
